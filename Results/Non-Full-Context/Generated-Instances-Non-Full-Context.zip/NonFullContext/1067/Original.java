/*
  * Copyright 2010 ZXing authors
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
 
 package com.google.zxing.aztec.decoder;
 
 import com.google.zxing.FormatException;
 import com.google.zxing.aztec.AztecDetectorResult;
 import com.google.zxing.common.BitMatrix;
 import com.google.zxing.common.DecoderResult;
 import com.google.zxing.common.reedsolomon.GenericGF;
 import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
 import com.google.zxing.common.reedsolomon.ReedSolomonException;
 
 import java.util.Arrays;
 
 /**
  * <p>The main class which implements Aztec Code decoding -- as opposed to locating and extracting
  * the Aztec Code from an image.</p>
  *
  * @author David Olivier
  */
 public final class Decoder {
 
   private enum Table {
     UPPER,
     LOWER,
     MIXED,
     DIGIT,
     PUNCT,
     BINARY
   }
 
   private static final String[] UPPER_TABLE = {
       "CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
       "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS"
   };
 
   private static final String[] LOWER_TABLE = {
       "CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p",
       "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS"
   };
 
   private static final String[] MIXED_TABLE = {
       "CTRL_PS", " ", "\1", "\2", "\3", "\4", "\5", "\6", "\7", "\b", "\t", "\n",
       "\13", "\f", "\r", "\33", "\34", "\35", "\36", "\37", "@", "\\", "^", "_",
       "`", "|", "~", "\177", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS"
   };
 
   private static final String[] PUNCT_TABLE = {
       "", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")",
       "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL"
   };
 
   private static final String[] DIGIT_TABLE = {
       "CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US"
   };
 
   private AztecDetectorResult ddata;
 
   public DecoderResult decode(AztecDetectorResult detectorResult) throws FormatException {
     ddata = detectorResult;
     BitMatrix matrix = detectorResult.getBits();
     boolean[] rawbits = extractBits(matrix);
     boolean[] correctedBits = correctBits(rawbits);
     byte[] rawBytes = convertBoolArrayToByteArray(correctedBits);
     String result = getEncodedData(correctedBits);
     DecoderResult decoderResult = new DecoderResult(rawBytes, result, null, null);
     decoderResult.setNumBits(correctedBits.length);
     return decoderResult;
   }
 
   // This method is used for testing the high-level encoder
   public static String highLevelDecode(boolean[] correctedBits) {
     return getEncodedData(correctedBits);
   }
 
   /**
    * Gets the string encoded in the aztec code bits
    *
    * @return the decoded string
    */
   private static String getEncodedData(boolean[] correctedBits) {
     int endIndex = correctedBits.length;
     Table latchTable = Table.UPPER; // table most recently latched to
     Table shiftTable = Table.UPPER; // table to use for the next read
     StringBuilder result = new StringBuilder(20);
     int index = 0;
     while (index < endIndex) {
       if (shiftTable == Table.BINARY) {
         if (endIndex - index < 5) {
           break;
         }
         int length = readCode(correctedBits, index, 5);
         index += 5;
         if (length == 0) {
           if (endIndex - index < 11) {
             break;
           }
           length = readCode(correctedBits, index, 11) + 31;
           index += 11;
         }
         for (int charCount = 0; charCount < length; charCount++) {
           if (endIndex - index < 8) {
             index = endIndex;  // Force outer loop to exit
             break;
           }
           int code = readCode(correctedBits, index, 8);
           result.append((char) code);
           index += 8;
         }
         // Go back to whatever mode we had been in
         shiftTable = latchTable;
       } else {
         int size = shiftTable == Table.DIGIT ? 4 : 5;
         if (endIndex - index < size) {
           break;
         }
         int code = readCode(correctedBits, index, size);
         index += size;
         String str = getCharacter(shiftTable, code);
         if (str.startsWith("CTRL_")) {
           // Table changes
           // ISO/IEC 24778:2008 prescribes ending a shift sequence in the mode from which it was invoked.
           // That's including when that mode is a shift.
           // Our test case dlusbs.png for issue #642 exercises that.
           latchTable = shiftTable;  // Latch the current mode, so as to return to Upper after U/S B/S
           shiftTable = getTable(str.charAt(5));
           if (str.charAt(6) == 'L') {
             latchTable = shiftTable;
           }
         } else {
           result.append(str);
           // Go back to whatever mode we had been in
           shiftTable = latchTable;
         }
       }
     }
     return result.toString();
   }
 
   /**
    * gets the table corresponding to the char passed
    */
   private static Table getTable(char t) {
     switch (t) {
       case 'L':
         return Table.LOWER;
       case 'P':
         return Table.PUNCT;
       case 'M':
         return Table.MIXED;
       case 'D':
         return Table.DIGIT;
       case 'B':
         return Table.BINARY;
       case 'U':
       default:
         return Table.UPPER;
     }
   }
 
   /**
    * Gets the character (or string) corresponding to the passed code in the given table
    *
    * @param table the table used
    * @param code the code of the character
    */
   private static String getCharacter(Table table, int code) {
     switch (table) {
       case UPPER:
         return UPPER_TABLE[code];
       case LOWER:
         return LOWER_TABLE[code];
       case MIXED:
         return MIXED_TABLE[code];
       case PUNCT:
         return PUNCT_TABLE[code];
       case DIGIT:
         return DIGIT_TABLE[code];
       default:
         // Should not reach here.
         throw new IllegalStateException("Bad table");
     }
   }
 
 
/**   <p>Performs RS error correction on an array of bits. */
 private boolean[] correctBits(boolean[] rawbits) throws FormatException{}

 

}